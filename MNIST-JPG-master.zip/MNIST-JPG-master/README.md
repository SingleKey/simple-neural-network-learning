# MNIST-JPG
This repository contains the MNIST dataset in JPG format. 
The converted files in JPG format is attached in a zip file. There is one folder each for Testing and Training 

I made this when I was playing around with MNIST and trying to understand ML. There was I think a repo that converted files to PNG. I wanted to test and train on JPG files and hence this simple python script. Since I didnt think the code would need further development, I have included a zip file of all the MNIST images. You can download and start using it straigtaway instead of bothering with the python file. 

The original inspiration is this repo:
https://github.com/myleott/mnist_png
